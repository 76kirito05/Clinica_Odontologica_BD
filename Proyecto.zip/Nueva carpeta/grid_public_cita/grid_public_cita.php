<?php 
  include_once('../grid_public_cita/index.php'); 
?> 
