<?php 
  include_once('../grid_public_almacen/index.php'); 
?> 
