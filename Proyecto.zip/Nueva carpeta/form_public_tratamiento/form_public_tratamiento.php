<?php 
  include_once('../form_public_tratamiento/index.php'); 
?> 
