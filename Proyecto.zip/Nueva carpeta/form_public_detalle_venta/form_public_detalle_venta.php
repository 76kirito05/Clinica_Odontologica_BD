<?php 
  include_once('../form_public_detalle_venta/index.php'); 
?> 
