<?php 
  include_once('../form_public_venta/index.php'); 
?> 
