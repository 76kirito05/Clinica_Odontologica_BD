<?php 
  include_once('../form_public_almacen/index.php'); 
?> 
