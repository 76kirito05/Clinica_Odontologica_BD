<?php 
  include_once('../form_public_producto/index.php'); 
?> 
