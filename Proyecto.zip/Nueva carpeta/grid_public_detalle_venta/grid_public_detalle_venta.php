<?php 
  include_once('../grid_public_detalle_venta/index.php'); 
?> 
