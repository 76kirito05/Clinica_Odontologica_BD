<?php 
  include_once('../form_public_paciente/index.php'); 
?> 
